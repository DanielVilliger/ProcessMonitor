#include <string>

#include "format.h"

using std::string;

// TODO: Complete this helper function
// INPUT: Long int measuring seconds
// OUTPUT: HH:MM:SS
// REMOVE: [[maybe_unused]] once you define the function
string Format::ElapsedTime(long seconds) { 
  long hours=(seconds/3600);
  long hours_rest=(seconds%3600);
  long minutes=hours_rest/60;
  long seconds_rest=hours_rest%60;
  string h=std::to_string(hours);
  string m=std::to_string(minutes);
  string s=std::to_string(seconds_rest);
  if(hours<10) h="0"+h;
  if(minutes<10)m="0"+m;
  if(seconds_rest<10)s="0"+s;
  return h+":"+m+":"+
    s; }