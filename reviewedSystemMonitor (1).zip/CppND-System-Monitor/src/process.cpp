#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include "linux_parser.h"
#include "process.h"

using std::string;
using std::to_string;
using std::vector;

// TODO: Return this process's ID
int Process::Pid() { return pid_0;}

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() { 
  std::ifstream file("/proc/"+std::to_string(pid_0)+"/stat");
  
  int counter_0=0;
  string line;
  string number;
  vector<string> container;
  std::getline(file,line);
  std::istringstream stream_neu(line);
  
  while(counter_0<13){
  stream_neu>>number;
  counter_0++;  
                }
  stream_neu>>number;
  container.push_back(number);
    stream_neu>>number;
  container.push_back(number);
    stream_neu>>number;
  container.push_back(number);
    stream_neu>>number;
  container.push_back(number);
  
  stream_neu>>number;
  stream_neu>>number;
  stream_neu>>number;
  stream_neu>>number;
  stream_neu>>number;
  container.push_back(number);
  vector<float> container_;
  for(auto vals:container)  container_.push_back(std::stof(vals));
  float total_time=container_[0]+container_[1];
  total_time=total_time+container_[2]+container_[3];
 float seconds=LinuxParser::UpTime(pid_0)-(container_[4]/sysconf(_SC_CLK_TCK));
  float cpu_usage = ((total_time / sysconf(_SC_CLK_TCK)) / seconds);
  //value_container to calculate for pid_0 the cpuutilization
  /*#14 utime - CPU time spent in user code, measured in clock ticks
#15 stime - CPU time spent in kernel code, measured in clock ticks
#16 cutime - Waited-for children's CPU time spent in user code (in clock ticks)
#17 cstime - Waited-for children's CPU time spent in kernel code (in clock ticks)
#22 starttime - Time when the process started, measured in clock ticks 
  total_time = utime + stime
total_time = total_time + cutime + cstime
seconds = uptime - (starttime / Hertz)
Finally we calculate the CPU usage percentage:

cpu_usage = 100 * ((total_time / Hertz) / seconds) */

 return cpu_usage; //return cpu_usage;
}
  

// TODO: Return the command that generated this process
string Process::Command() { return LinuxParser::Command(pid_0); }

// TODO: Return this process's memory utilization
string Process::Ram() { return LinuxParser::Ram(pid_0); }

// TODO: Return the user (name) that generated this process
string Process::User() { return LinuxParser::User(pid_0); }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { return LinuxParser::UpTime(pid_0); }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process const& a) const { 
  if(pid_0<a.pid_0) return true;
  else return false; }