#include "ncurses_display.h"
#include "system.h"
#include "linux_parser.h"
#include <iostream>
#include <string>

int main() {
  
  //std::string a=LinuxParser::Uid(7);
  //std::string b=LinuxParser::User(7);
  //std::cout << a << std::endl;
  //std::cout << b << std::endl;
  System system;
  NCursesDisplay::Display(system);
}