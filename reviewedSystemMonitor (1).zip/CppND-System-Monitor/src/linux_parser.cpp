#include <dirent.h>
#include <unistd.h>
#include <sstream>
#include <string>
#include <vector>
#include <iostream> // function test

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
//Helperfunction for debugging
template <typename T>
void helpfunc(T x){
std::cout << "Printed: " << x << std::endl;
}
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, kernel, version;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() {
  string line;
  string in_;
  string in_0;
  vector<string> vec;  // two Memory values
  int counter=0;
  
  std::ifstream file(kProcDirectory+kMeminfoFilename);
  
  if(file.is_open()){
    while(counter<2){
    std::getline(file, line);
    std::istringstream linestream(line);
    linestream >> in_ >> in_0;
    vec.push_back(in_0);
    counter++;
    }
  }
  
  float memtotal=stof(vec[0]);
  float memfree=stof(vec[1]);
  return (memtotal-memfree)/memtotal; }  

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 
  string c_0;
  string line;
  long a;
  
  
  std::ifstream file(kProcDirectory+kUptimeFilename);
  if(file.is_open()){
    std::getline(file, line);
    std::istringstream linestream(line);
    linestream >> c_0;
    a=long(stof(c_0));  
 }
   return a;
}

// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() {  
 return long((std::stof((LinuxParser::CpuUtilization())[2])));
  }

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid) { 
string number=to_string(pid);
std::ifstream file("/proc/"+number+"/stat");
string line;
string in_;
string var_;
 int counter=0;
if(file.is_open()){
while(counter<2){
std::getline(file,line);
std::istringstream linestream(line);
    linestream >> in_;
    linestream >> in_;
    linestream >> in_;
    linestream >> in_;
    linestream >> in_;
  if(counter==1) var_=in_;
  counter++;
}
return 0; 
}


  
  
return std::stol(var_)/sysconf(_SC_CLK_TCK);;  
}
// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() { return 0; }

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() {  return long((std::stof((LinuxParser::CpuUtilization())[3]))); }

// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() { 
  vector<string> vec;
  string line;
  string in_;
  std::ifstream file(kProcDirectory+kStatFilename);
 if(file.is_open()){
  getline(file,line);
  std::istringstream linestream(line);
    linestream >> in_;
    linestream >> in_;  //1
    vec.push_back(in_);
    linestream >> in_;   //2
    vec.push_back(in_);
  linestream >> in_;    //3
    vec.push_back(in_);
  linestream >> in_;    //4
    vec.push_back(in_);
  linestream >> in_;    //5
    vec.push_back(in_);
  linestream >> in_;    //6
    vec.push_back(in_);
  linestream >> in_;    //7
    vec.push_back(in_);
  linestream >> in_;   // 8
    vec.push_back(in_);
  linestream >> in_;   //9
    vec.push_back(in_);
  linestream >> in_;  //10
    vec.push_back(in_);
  linestream >> in_;
    vec.push_back(in_);}
  return vec;}

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() { 
  std::ifstream file(kProcDirectory+kStatFilename);
  string line;
  string c_0;
  int c_1;
  int proc;
  if(file.is_open()){
    while(getline(file,line)){
    std::istringstream stream(line);
    stream >> c_0 >> c_1;
    if(c_0=="processes") {proc=c_1;
                          
                         break;}
    }
  }
  return proc; }

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() { std::ifstream file(kProcDirectory+kStatFilename);
  string line;
  string c_0;
  int c_1;
  int proc;
  if(file.is_open()){
    while(getline(file,line)){
    std::istringstream stream(line);
    stream >> c_0 >> c_1;
    if(c_0=="procs_running") {proc=c_1;
                              //test
                              return c_1;
                         break;}
    }
  }
                                     
  return proc; }

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) {
  string line;
  string neu_line;
  std::ifstream file("/proc/"+to_string(pid)+"/cmdline");
  if(file.is_open()){
  getline(file,line);
  neu_line=line;}
  
  return neu_line; 
}

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) { 
  string line;
  string c_0,c_1,string_val;
  std::ifstream file("/proc/"+to_string(pid)+"/status");
  if(file.is_open()){
  while(getline(file,line)){
  std::istringstream neustream(line);
  neustream >> c_0 >> c_1;
  
    if(c_0=="VmSize:") {
     string_val=c_1;
      
  }  
  }
  }
  /*if(string_val != ""){
    return std::stoi(string_val);
}*/
  if(string_val !="") return to_string(std::stoi(string_val)/1000);
  else return "0";
  
   }

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) { 
  string line;
  string c_0;
  string c_1;
  string ret_val;
  std::ifstream file( kProcDirectory+std::to_string(pid)+kStatusFilename);
  if(file.is_open()){
  while(getline(file,line)){
  std::istringstream stream(line);
    stream >> c_0 >> c_1;
    //helpfunc<string>(c_0);
    //helpfunc<string>(c_1);
    if(c_0=="Uid:"){ ret_val=c_1;
                   break;}
  }
  }
 
  return ret_val;
  }

// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) {
  
  string compare_var=LinuxParser::Uid(pid);
  string d_,d_0,d_1;
  string name;
  string f_name;
  string line;                                             
  std::ifstream file_neu("/etc/passwd");
  if(file_neu.is_open()){
  while(getline(file_neu,line)){
  std::replace(line.begin(),line.end(),':',' ');
  std::istringstream stream_neu(line);
  stream_neu>>d_>>d_0>>d_1;
  if(d_1==compare_var) {
                    return d_;
      
     
     } 
   }} 
 return "";
 }

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) { 
    string line;
    string c_0;
    string a;
    std::ifstream file("/proc/"+std::to_string(pid)+"/stat");
    int i=0;
    if(file.is_open()){
         std::getline(file,line);
        std::istringstream stream(line);
        while(i<22){
        
        stream >> c_0;
        if(i==21){
         a=c_0;
          break;
        }//c_0;
          i++;
        }
   
    }
  long uptime = LinuxParser::UpTime() - std::stol(a)/sysconf(_SC_CLK_TCK);
  return uptime;
}

   

