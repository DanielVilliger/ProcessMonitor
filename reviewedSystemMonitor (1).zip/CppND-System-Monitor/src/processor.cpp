#include "processor.h"
#include "linux_parser.h"
#include <vector>
#include <string>

using std::vector;
using std::string;
// TODO: Return the aggregate CPU utilization


float Processor::Utilization() { /*
https://stackoverflow.com/questions/23367857/accurate-calculation-of-cpu-usage-given-in-percentage-in-linux
  PrevIdle = previdle + previowait
Idle = idle + iowait

PrevNonIdle = prevuser + prevnice + prevsystem + previrq + prevsoftirq + prevsteal
NonIdle = user + nice + system + irq + softirq + steal

PrevTotal = PrevIdle + PrevNonIdle
Total = Idle + NonIdle

# differentiate: actual value minus the previous one
totald = Total - PrevTotal
idled = Idle - PrevIdle

CPU_Percentage = (totald - idled)/totald  */
 /* user    nice   system  idle      iowait irq   softirq  steal  guest  guest_nice
cpu  74608   2520   24433   1117073   6176   4054  0        0      0      0  */
  vector<float> vec_float{};
  vector<string> vec=LinuxParser::CpuUtilization();
  for(auto val:vec) vec_float.push_back(std::stof(val));
  float Idle=vec_float[3]+vec_float[4];
  float NonIdle=vec_float[0]+vec_float[1]+vec_float[2]+vec_float[5]
    +vec_float[6]+vec_float[7];
  float Total=NonIdle+Idle;
  float totald=Total;  // assignment ... exact calculation formula
  float idled=Idle;   // assignment .. exact calculation formula
  return (totald-idled)/totald; }